//: Playground - noun: a place where people can play

import UIKit

var numeros = 1...100

for n in numeros {
    switch n {
    // Evalua si es divisible entre 5
    case n where n % 5 == 0:
        print("\(n) Bingo!!!\n")
    // Evalua si es par
    case n where n % 2 == 0:
        print("\(n) Par!!!\n")
    // Evalua si es impar
    case n where n % 2 != 0:
        print("\(n) Impar!!!\n")
    default:
        print("\(n) \n")
    }
    
    // Evalua el rango de 30 a 40
    switch n {
    case 30...40:
        print("\(n) Viva swift!!!\n")
    default:
        print("")
    }
    
}
